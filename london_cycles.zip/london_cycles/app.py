from flask import Flask, render_template, request, make_response, send_file
from flask_paginate import Pagination, get_page_args
import pandas as pd
import csv
import os
import io
import folium
import base64
from clean import clean_df
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import base64
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from map import mapPoints

from dashboard import get_most_popular_weekdays, get_least_popular_weekdays, bike_rental_duration
from map import mapPoints

app = Flask(__name__)
container = []
new_df = []
turnover=[]
fig, ax = plt.subplots(figsize=(5, 4))
ax = sns.set_style(style="darkgrid")

def get_data(new_df, offset=0, perPage=10):
    return new_df[offset: offset + perPage]

# Display data before cleaning and upload to downloads
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == "POST":
        f = request.files['csvfile']
        if not os.path.isdir('downloads'):
            os.mkdir('downloads')
        global filepath
        filepath = os.path.join('downloads', f.filename)
        f.save(filepath)
        file = open(filepath, 'r')
        global container
        container = pd.read_csv(filepath, header=[0])
        return render_template('data.html', header = container.head(), column_names = container.columns.values, row_data = list(container.values.tolist()), zip=zip, data=container, filename=filepath.split('/')[1], shape=container.shape)
    return render_template('index.html')

@app.route('/clean', methods=['GET', 'POST'])
def clean_csv():
    fp = filepath
    container = clean_df(fp)
    global new_df
    new_df = container.copy()
    page, perPage, offset = get_page_args(page_parameter='page', per_page_parameter='per_page')
    total = new_df.shape[0]
    pagination_data = get_data(new_df, offset=offset, perPage=perPage)
    pagination = Pagination(page=page, perPage=perPage, total=total, css_framework='bootstrap4')
    return render_template('clean.html', data = pagination_data,page=page,perPage=50,pagination=pagination,header = pagination_data.head(), column_names = pagination_data.columns.values, row_data = list(pagination_data.values.tolist()), zip=zip, filename=filepath.split('/')[1], shape=container.shape)


# Display data visualization
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboardPage():
    most_popular = get_most_popular_weekdays(new_df)
    least_popular = get_least_popular_weekdays(new_df)
    global df2
    df2 = pd.read_csv('downloads/london_cycle_stations - london_cycle_stations.csv', header=[0])
    global turnover
    turnover = mapPoints(new_df,df2)
    rental_duration = bike_rental_duration(new_df)
    labels = rental_duration['duration']
    values = rental_duration['rental_id']
    ndf = new_df.copy()
    return render_template('dashboard.html',rental_duration=rental_duration,labels=labels,values=values, most_popular=most_popular,most_header = most_popular.head(), most_column_names = most_popular.columns.values, most_row_data = list(most_popular.values.tolist()), 
                            least_popular=least_popular, least_header = least_popular.head(), least_column_names = least_popular.columns.values, least_row_data = list(least_popular.values.tolist()),zip=zip, turnover=turnover, turn_header = turnover.head(), turn_column_names = turnover.columns.values, 
                            turn_row_data = list(turnover.values.tolist()))

# Display histogram plot in visualisation page
@app.route('/visualize')
def visualize():
    rental_duration = bike_rental_duration(new_df)
    sns.histplot(data=rental_duration, x="duration", stat="frequency")
    canvas= FigureCanvas(fig)
    plt.xlabel="duration (minutes)"
    plt.xlim(0,120)
    img = io.BytesIO()
    fig.savefig(img)
    img.seek(0)
    return send_file(img, mimetype='img/png')

# Display map of most turnover stations
@app.route('/map', methods=['GET','POST'])
def mapBicycle():
    map_df = turnover[['latitude','longitude','start_station_name']]
    flag = 0
    for latitude, longitude, station in zip(map_df['latitude'],map_df['longitude'],map_df['start_station_name']):
        if flag == 0:
            map = folium.Map(
                location=[latitude, longitude],
                popup="<b>"+station+"</b>",
                zoom_start=13
            )
            flag = 1
        folium.Marker(
            location=[latitude, longitude],
            popup="<b>"+station+"</b>",
            icon=folium.Icon(color='red')
        ).add_to(map)
    map.save('templates/mapDemo.html')
    return render_template('map.html')

# Download the cleaned data
@app.route('/download', methods=['GET', 'POST'])
def download():
    resp = make_response(new_df.to_csv())
    dateTimeObj = datetime.now()
    content = "attachment; filename="+ filepath.split('/')[1].split('.')[0]+dateTimeObj.strftime("%b%d") +".csv"
    resp.headers["Content-Disposition"] = content
    resp.headers["Content-Type"] = "text/csv"
    return resp


if __name__ == "__main__":
    app.run(debug=True)