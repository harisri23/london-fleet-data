from codecs import ignore_errors
import pandas as pd
import numpy as np

def clean_df(filepath):
    # rental_id,duration,bike_id,end_date,end_station_id,end_station_name,start_date,start_station_id,start_station_name
    file = open(filepath, 'r')
    global container
    missing_values = ["n/a", "na", "--"]
    container = pd.read_csv(filepath, header=[0], na_values = missing_values)
    if filepath.split('/')[1] == "london_cycle_hires_extract - london_cycle_hires_extract.csv":
        #converting datatypes
        container['rental_id'] = pd.to_numeric(container['rental_id'], errors='coerce').astype('Int64')
        container['duration'] = np.floor(pd.to_numeric(container['duration'], errors='coerce')).astype('Int64')
        container['bike_id'] = pd.to_numeric(container['bike_id'], errors='coerce').astype('Int64')
        container['end_station_id'] = pd.to_numeric(container['end_station_id'], errors='coerce').astype('Int64')
        container['end_station_name'] = container['end_station_name'].astype('string')
        container['start_station_id'] = pd.to_numeric(container['start_station_id'], errors='coerce').astype('Int64')
        container['start_station_name'] = container['start_station_name'].astype('string')
        container['end_date'] = pd.to_datetime(container['end_date'], errors='coerce', format='%Y-%m-%d %H:%M:%S %Z')
        container['start_date'] = pd.to_datetime(container['start_date'], errors='coerce', format='%Y-%m-%d %H:%M:%S %Z')

        #drop Nan values
        container = container.dropna()

        #drop duplicates
        container = container.drop_duplicates(subset='rental_id', keep="first")
        

    if filepath.split('/')[1] == "london_cycle_stations - london_cycle_stations.csv":
        #converting datatypes
        container['id'] = pd.to_numeric(container['id'], errors='coerce').astype('Int64')
        container['install_date'] = pd.to_datetime(container['install_date'], errors='coerce', format='%Y-%m-%d')
        container['installed'] = container['installed'].astype('bool')
        container['latitude'] = container['latitude'].astype(float)
        container['locked'] = container['locked'].astype('string')
        container['longitude'] = container['longitude'].astype(float)
        container['name'] = container['name'].astype('string')
        container['bikes_count'] = pd.to_numeric(container['bikes_count'], errors='coerce').astype('Int64')
        container['docks_count'] = pd.to_numeric(container['docks_count'], errors='coerce').astype('Int64')
        container['nbEmptyDocks'] = pd.to_numeric(container['nbEmptyDocks'], errors='coerce').astype('Int64')
        container['removal_date'] = pd.to_datetime(container['removal_date'], errors='coerce', format='%Y-%m-%d')
        container['temporary'] = container['temporary'].astype('bool')
        container['terminal_name'] = container['terminal_name'].astype('string')

        #drop duplicates
        container = container.drop_duplicates(subset='id', keep="first")

    return container
