import pandas as pd
import numpy as np
import pandasql as ps

# Function to extract 10 most popular stations on weekdays
def get_most_popular_weekdays(df):  
    q1 = '''
    SELECT CAST(strftime('%w', start_date) as INT) AS Day, start_station_name, start_station_id , count(start_station_id) as station_count
    from df
    where DAY between 0 and 4
    group by start_station_id
    order by count(start_station_id) desc
    limit 10
    '''
    return (ps.sqldf(q1, locals()))

# Function to extract 10 least popular stations on weekdays
def get_least_popular_weekdays(df):
    q2 = '''
    SELECT CAST(strftime('%w', start_date) as INT) AS Day, start_station_name, start_station_id , count(start_station_id) as station_count
    from df
    where DAY between 0 and 4
    group by start_station_id
    order by count(start_station_id)
    limit 10
    '''
    return (ps.sqldf(q2, locals()))

# Function to extract bike rental duration in minutes
def bike_rental_duration(df):
    q3 = '''
    SELECT rental_id, (duration/60) as duration
    from df
    '''
    return (ps.sqldf(q3, locals()))
