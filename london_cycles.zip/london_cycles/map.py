import pandas as pd
import matplotlib.pyplot as plt    
import pandasql as ps
import folium

# Function to extract stations with most turnover with their latitude and longitude
def mapPoints(df1, df2):
    q3 = '''
    SELECT df1.start_station_id, df1.start_station_name, df2.latitude, df2.longitude, sum(df1.duration)/count(df1.bike_id) as Turnover 
    from df1
    INNER JOIN df2
    on df1.start_station_id = df2.id
    group by df1.start_station_id
    order by sum(df1.duration)/count(df1.bike_id) desc
    limit 10
    '''
    return (ps.sqldf(q3, locals()))

